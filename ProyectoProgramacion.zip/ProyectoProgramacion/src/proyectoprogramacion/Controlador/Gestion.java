package proyectoprogramacion.Controlador;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import proyectoprogramacion.Modelo.Escuelas;

public class Gestion {
    private Escuelas[]grupo;
    public Escuelas[] getGrupo() {
        return grupo;
    }
    public void setGrupo(Escuelas[] grupo) {
        this.grupo = grupo;
    }
    public Gestion(){
        this.grupo= new Escuelas[0];
        
    }
    public void NuevaEscuela(Escuelas nueva){
        if(this.grupo.length==0){
            this.grupo=new Escuelas[1];
            this.grupo[0]=nueva;
            
        }
        else{
            Escuelas[] temporal= new Escuelas[this.grupo.length];
            for (int i = 0; i < temporal.length; i++) {
                temporal[i]=this.grupo[i];

            }

            this.grupo=new Escuelas[temporal.length+1];
            for (int i = 0; i < temporal.length; i++) {
              this.grupo[i]=temporal[i] ;
            }
            this.grupo[this.grupo.length-1]=nueva;
        }
    }
    public void EliminarEscuela(String nombre){
        for(int i=0;i<this.grupo.length;i++){
            if(nombre.equals(this.grupo[i].getDirector())){
                if(i!=this.grupo.length){
                    Escuelas [] temporal= new Escuelas [this.grupo.length];
                    for(int j=0; j<temporal.length;j++){
                        if(j<i){
                            temporal[j]=this.grupo[j];
                        }else{
                            temporal[j]=this.grupo[j+1];
                        }
                    }
                    this.grupo=new Escuelas[temporal.length-1];
                    for (int j = 0; j < temporal.length-1; j++) {
                        this.grupo[j]=temporal[j];
                    }
                    return;
                }
            }else{
                Escuelas[]temporal=new Escuelas[this.grupo.length-1];
                for(int j=0;j<temporal.length;j++){
                    temporal[j]=this.grupo[j];
                }
                this.grupo=new Escuelas[temporal.length];
                this.grupo=temporal;
            }
        }
    }
    public Escuelas[] Importar(Escuelas[]newgroup,String s) throws IOException,ClassNotFoundException{
                File file=new File("archivos\\"+s+".txt");
                FileInputStream entrada=new FileInputStream(file);
                ObjectInputStream obj=new ObjectInputStream(entrada);
                int tam=obj.readInt();
                Escuelas[]g=new Escuelas[tam];
                for(int i=0;i<tam;i++){
                    Object o=obj.readObject();
                    Escuelas p=(Escuelas)o;
                    g[i]=p;
                    System.out.println(g[i].getDirector()); 
                }
                newgroup=g;
                obj.close();
                return newgroup;
                }

        
    
    public void Exportar(Escuelas[]p, String s) throws IOException {
        File file=new File("Archivos\\"+".txt");
        FileOutputStream salida=new FileOutputStream(file);
        ObjectOutputStream obj=new ObjectOutputStream(salida);
        obj.writeInt(p.length);
        for(int i=0;i<p.length;i++){
            obj.writeObject(p[i]);
        }

        obj.flush();

        obj.close();

        
    }
}
