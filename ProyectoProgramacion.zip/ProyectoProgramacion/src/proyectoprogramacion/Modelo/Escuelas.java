package proyectoprogramacion.Modelo;

public class Escuelas {
    private int alumnos;
    private int maestros;
    private String director;

    public int getAlumnos() {
        return alumnos;
    }
    public void setAlumnos(int alumnos) {
        this.alumnos = alumnos;
    }
    
    public int getMaestros() {
        return maestros;
    }
    public void setMaestros(int maestros) {
        this.maestros = maestros;
    }
    
   public String getDirector() {
        return director;
    }
    public void setDirector(String director) {
        this.director = director;
    }

    public Escuelas (int alumnos,int maestros,String director){
        this.alumnos=alumnos;
        this.maestros= maestros;

        this.director= director;
    }

   }